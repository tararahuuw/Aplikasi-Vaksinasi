package com.example.perludilindungi.db

import android.util.Log
import android.widget.Toast
import androidx.lifecycle.LiveData

class BookmarkRepository(private val bookmarDao: BookmarkDao) {

    val readAllData: LiveData<List<Bookmark>> = bookmarDao.getAllBookmarks()

    suspend fun addBookmark(bookmark: Bookmark){
        try {
            bookmarDao.insert(bookmark)
        }
        catch (ex:Exception) {
            //your error handling code here
            //here, consider adding Log.e("SmsReceiver", ex.localizedMessage)
            //this log statement simply prints errors to your android studio terminal and will help with debugging, alternatively leave it out
            Log.e("Bookmark Id", ex.localizedMessage)
            bookmarDao.deleteBookmarkById(bookmark.id_api)
        }
    }

    suspend fun deleteBookmarkById(id_api: Int){
        bookmarDao.deleteBookmarkById(id_api)
    }

    fun getBookmarkById(id_api: Int) : Boolean = bookmarDao.getBookmarkById(id_api)
}
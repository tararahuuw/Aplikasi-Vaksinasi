package com.example.perludilindungi.model.location

class ProvinsiModel {
    val curr_val : String = "null"
        get() {
            return field
        }
    val message : String = "null"
        get() {
            return field
        }
    val results : List<ResultProvinsiModel>? = null
        get() {
            return field
        }
}
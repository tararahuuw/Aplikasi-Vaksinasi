package com.example.perludilindungi.db

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BookmarkViewModel(application: Application): AndroidViewModel(application) {
    val readAllData: LiveData<List<Bookmark>>
    private val repository: BookmarkRepository

    init {
        val bookmarkDao = BookmarkDatabase.getInstance(application).getBookmarkDao()
        repository = BookmarkRepository(bookmarkDao)
        readAllData = repository.readAllData
    }

    fun addBookmark(bookmark: Bookmark){
        viewModelScope.launch(Dispatchers.IO) {
            repository.addBookmark(bookmark)
        }
    }
}
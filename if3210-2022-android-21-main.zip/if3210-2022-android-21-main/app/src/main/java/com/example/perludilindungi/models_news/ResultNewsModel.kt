package com.example.perludilindungi.models_news

class ResultNewsModel {
    val title : String = "null"
        get() {
            return field
        }
    val pubDate : String = "null"
        get() {
            return field
        }

    val link : Array<String>? = null
        get() {
            return field
        }

    val enclosure : EnclosureModel? = null
        get() {
            return field
        }
}
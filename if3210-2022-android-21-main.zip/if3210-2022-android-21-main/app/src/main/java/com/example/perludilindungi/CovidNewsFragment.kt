package com.example.perludilindungi

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.WebSettings
import android.webkit.WebView
import android.widget.ProgressBar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.perludilindungi.adapter.NewsAdapter
import com.example.perludilindungi.models_news.NewsModel
import com.example.perludilindungi.retrofit.ApiServices
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class CovidNewsFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val bundle:Bundle? = arguments
        val urlData : String? = bundle?.getString("urlNews")

        val myView = inflater.inflate(R.layout.fragment_covid_news, container, false)
        // Inflate the layout for this fragment

        val progressBar2 : ProgressBar = myView.findViewById(R.id.progressBar2)
        progressBar2.setVisibility(View.VISIBLE);

        val mWebView : WebView = myView.findViewById(R.id.webView1)
        mWebView.loadUrl(urlData.toString())

        val webSettings : WebSettings = mWebView.getSettings()
        webSettings.setJavaScriptEnabled(true)
        progressBar2.setVisibility(View.GONE);
//        ApiServices.endpoint.getNews()
//            .enqueue(object : Callback<NewsModel> {
//                override fun onResponse(call: Call<NewsModel>, response: Response<NewsModel>) {
//                    if (response.isSuccessful) {
//                        progressBar2.setVisibility(View.GONE);
//
//                        val mWebView : WebView = myView.findViewById(R.id.webView1)
//                        mWebView.loadUrl(response.body()?.results?.get(0)?.link?.get(0).toString())
//
//                        val webSettings : WebSettings = mWebView.getSettings()
//                        webSettings.setJavaScriptEnabled(true)
//                        }
//                    }
//
//                override fun onFailure(call: Call<NewsModel>, t: Throwable) {
//                    progressBar2.setVisibility(View.GONE);
//                    Log.i("Message", "Failed Fetching Data")
//                }
//            })
        return myView
    }
}
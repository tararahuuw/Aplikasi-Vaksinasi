package com.example.perludilindungi.model.location

class ResultProvinsiModel {
    val key : String = "null"
        get() {
            return field
        }
    val value : String = "null"
        get() {
            return field
        }
}
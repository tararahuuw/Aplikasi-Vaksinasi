package com.example.perludilindungi.model.location

class KotaModel {
    val curr_val : String = "null"
        get() {
            return field
        }
    val message : String = "null"
        get() {
            return field
        }
    val results : List<ResultKotaModel>? = null
        get() {
            return field
        }
}

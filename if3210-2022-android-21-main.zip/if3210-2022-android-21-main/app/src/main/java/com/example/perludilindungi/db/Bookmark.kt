package com.example.perludilindungi.db

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(indices = [Index(value = ["kode"], unique = true) ])
data class Bookmark(
    @ColumnInfo(name = "id_api", defaultValue = "-1") val id_api: Int,
    @ColumnInfo(name = "kode", defaultValue = "404") val kode: String,
    @ColumnInfo(name = "nama", defaultValue = "lorem ipsum") val nama: String,
    @ColumnInfo(name = "alamat", defaultValue = "sir dolor amet") val alamat: String,
    @ColumnInfo(name = "telp", defaultValue = "+62812") val telp: String,
    @ColumnInfo(name = "jenis_faskes", defaultValue = "unknown") val jenis_faskes: String,
    @ColumnInfo(name = "status", defaultValue = "missing") val status: String,
    @ColumnInfo(name = "longitude", defaultValue = "0.0") val longitude: Double,
    @ColumnInfo(name = "latitude", defaultValue = "0.0") val latitude: Double
){
    @PrimaryKey(autoGenerate = true)
    var id: Int? = null
}


import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.perludilindungi.R
import com.example.perludilindungi.adapter.BookmarkAdapter
import com.example.perludilindungi.adapter.NewsAdapter
import com.example.perludilindungi.db.Bookmark
import com.example.perludilindungi.db.BookmarkDao
import com.example.perludilindungi.db.BookmarkDatabase
import com.example.perludilindungi.db.BookmarkViewModel
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class BookmarkFragment:Fragment() {
    private var layoutManager: RecyclerView.LayoutManager? = null
    private var adapter: RecyclerView.Adapter<BookmarkAdapter.ViewHolder>? = null

    private lateinit var mBookmarkViewModel: BookmarkViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        mBookmarkViewModel = ViewModelProvider(this).get(BookmarkViewModel::class.java)

//        insertDataToDatabase()

        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_bookmark, container, false)

    }

    override fun onViewCreated(itemView: View, savedInstanceState: Bundle?) {
        super.onViewCreated(itemView, savedInstanceState)

        val progressBar : ProgressBar = itemView.findViewById(R.id.progressBar)
        val recyclerView: RecyclerView = itemView.findViewById(R.id.recyclerView)
        val adapter = BookmarkAdapter(emptyList<Bookmark>())
        progressBar.setVisibility(View.VISIBLE)
        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(requireContext())

        // UserViewModel
        mBookmarkViewModel = ViewModelProvider(this).get(BookmarkViewModel::class.java)
        mBookmarkViewModel.readAllData.observe(viewLifecycleOwner, Observer { bookmark ->
            progressBar.setVisibility(View.GONE)
            adapter.setDataBookmark(bookmark)
        })
//        GlobalScope.launch {
//            bookmark = dao.getAllBookmarks()
//            Log.d("TAG", bookmark.toString())
//            recyclerView.apply {
//                // set a LinearLayoutManager to handle Android
//                // RecyclerView behavior
//                layoutManager = LinearLayoutManager(activity)
//                // set the custom adapter to the RecyclerView
//                adapter = BookmarkAdapter(bookmark)
//            }
//        }
    }

    private fun insertDataToDatabase() {
        // Create Bookmark Object
//        val bookmark1 = Bookmark("10040305", "Faskes Nomor 1", "Jl. Mayjen H.R. Edi Sukma No. 75, Watesjaya, Cigombong, Bogor, Jawa Barat 16740, Indonesia", "(0251)8221047", "Puskesmas")
        // Add Data to Database
//        mBookmarkViewModel.addBookmark(bookmark1)
        Toast.makeText(requireContext(), "Successfully added!", Toast.LENGTH_LONG).show()
    }
}
package com.example.perludilindungi.retrofit

import com.example.perludilindungi.model.faskes.FaskesModel
import com.example.perludilindungi.model.location.KotaModel
import com.example.perludilindungi.model.location.ProvinsiModel
import com.example.perludilindungi.models_news.NewsModel
import com.example.perludilindungi.models_scanner.ScannerModelResponse
import retrofit2.Call
import retrofit2.http.*

interface ApiEndpoint {

    @GET("api/get-news")
    fun getNews() : Call<NewsModel>

    //post user using field x-www-form-urlencoded
    @FormUrlEncoded
    @POST("check-in")
    fun postScanner(
        @Field("qrCode") qrCode: String,
        @Field("latitude") latitude: Int,
        @Field("longitude") longitude: Int,
    ): Call<ScannerModelResponse>

    @GET("api/get-province")
    fun getProvince() : Call<ProvinsiModel>

    @GET("api/get-city")
    fun getCity(
        @Query("start_id") province: String
    ) : Call<KotaModel>

    @GET("api/get-faskes-vaksinasi")
    fun getFaskes(
        @Query("province") province: String,
        @Query("city") city: String
    ) : Call<FaskesModel>
}
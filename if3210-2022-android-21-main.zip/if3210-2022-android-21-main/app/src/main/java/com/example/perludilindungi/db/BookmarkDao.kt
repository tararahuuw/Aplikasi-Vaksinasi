package com.example.perludilindungi.db

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query

@Dao
interface BookmarkDao {
    @Query("SELECT * FROM bookmark")
    fun getAllBookmarks(): LiveData<List<Bookmark>>

    @Query("SELECT EXISTS (SELECT 1 FROM bookmark WHERE id_api = :id_api)")
    fun getBookmarkById(id_api: Int): Boolean

    @Insert
    fun insert(vararg bookmark: Bookmark)

    @Query("DELETE FROM bookmark WHERE id_api = :id_api")
    fun deleteBookmarkById(id_api: Int)

}
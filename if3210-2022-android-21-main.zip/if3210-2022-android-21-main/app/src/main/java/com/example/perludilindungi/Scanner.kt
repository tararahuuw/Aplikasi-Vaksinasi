package com.example.perludilindungi

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.SearchManager
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.location.Location
import android.net.Uri
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.View
import androidx.core.app.ActivityCompat

import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.perludilindungi.adapter.NewsAdapter
import com.example.perludilindungi.models_news.NewsModel
import com.example.perludilindungi.models_scanner.ScannerModelResponse
import com.example.perludilindungi.retrofit.ApiServices
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.zxing.integration.android.IntentIntegrator
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import android.hardware.SensorManager
import android.widget.*

class Scanner : AppCompatActivity(), SensorEventListener {
    private var fusedLocationClient: FusedLocationProviderClient? = null
    private var lastLocation: Location? = null
    private var latitudeLabel: String? = null
    private var longitudeLabel: String? = null
    private var titleScanner: TextView? = null
    private var descScanner: TextView? = null
    private var imageScanner: ImageView? = null
    private var textTemperature : TextView? = null
    private lateinit var sensorManager : SensorManager
    private var tempSensor : Sensor? = null
    private var isTempAvailable : Boolean? = false
    private var progressBar : ProgressBar? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_scanner)
        latitudeLabel = resources.getString(R.string.latitudeBabel)
        longitudeLabel = resources.getString(R.string.longitudeBabel)
        titleScanner = findViewById<View>(R.id.title_scanner) as TextView
        descScanner = findViewById<View>(R.id.desc_scanner) as TextView
        imageScanner = findViewById<View>(R.id.image_scanner) as ImageView
        textTemperature = findViewById(R.id.temperature)
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        val progressBar = findViewById<View>(R.id.progressBarScanner) as ProgressBar
        val button_back: Button = findViewById(R.id.button_back)

        progressBar.setVisibility(View.INVISIBLE);

        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        if (sensorManager.getDefaultSensor(Sensor.TYPE_AMBIENT_TEMPERATURE) != null) {
            Toast.makeText(this, "Your Device Support Temperature Sensor !", Toast.LENGTH_LONG).show()
            tempSensor = sensorManager.getDefaultSensor(Sensor.TYPE_AMBIENT_TEMPERATURE)
            textTemperature?.text = "0 °C"
            isTempAvailable = true
        } else {
            Toast.makeText(this, "No Ambient Temperature Sensor !", Toast.LENGTH_LONG).show()
            isTempAvailable = false
            textTemperature?.text = "nosensor"
        }

        val qrButton: Button = findViewById(R.id.qr_button)
        qrButton.setOnClickListener({
            val intentIntegrator = IntentIntegrator(this)
            intentIntegrator.setDesiredBarcodeFormats(listOf(IntentIntegrator.QR_CODE))
            intentIntegrator.initiateScan()
        })

        button_back.setOnClickListener({
            onBackPressed()
        })


    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        progressBar?.setVisibility(View.VISIBLE);
        super.onActivityResult(requestCode, resultCode, data)
        val result = IntentIntegrator.parseActivityResult(resultCode, data)

        if (result != null) {
            val client = ApiServices.endpoint.postScanner(result.contents.toString(),(lastLocation)!!.latitude.toInt(),(lastLocation)!!.longitude.toInt())
            client.enqueue(object : Callback<ScannerModelResponse> {
                override fun onResponse(
                    call: Call<ScannerModelResponse>,
                    response: Response<ScannerModelResponse>
                ) {
                    val responseBody = response.body()
                    if (response.isSuccessful && responseBody != null) {
                        progressBar?.setVisibility(View.INVISIBLE);
                        descScanner?.text = responseBody.data?.reason.toString()
                        when(responseBody.data?.userStatus.toString()) {
                            "green" -> {
                                imageScanner?.setImageResource(R.drawable.ok)
                                titleScanner?.text = "Berhasil"
                            }
                            "red" -> {
                                imageScanner?.setImageResource(R.drawable.danger)
                                titleScanner?.text = "Gagal"
                            }
                            "yellow" -> {
                                imageScanner?.setImageResource(R.drawable.ok)
                                titleScanner?.text = "Berhasil"
                            }
                            "black" -> {
                                imageScanner?.setImageResource(R.drawable.danger)
                                titleScanner?.text = "Gagal"
                            }
                        }
                    } else {
                        Log.e(TAG, "onFailure: ${response.isSuccessful} duar")
                    }
                }
                override fun onFailure(call: Call<ScannerModelResponse>, t: Throwable) {
                    Log.e(TAG, "onFailure: ${t.message}")
                    progressBar?.setVisibility(View.INVISIBLE);
                    Toast.makeText(this@Scanner,"masuk onfailure",Toast.LENGTH_SHORT).show()
                }
            })
        }
        else {
            Toast.makeText(this@Scanner,"QR CODE Not Detected",Toast.LENGTH_SHORT).show()
            progressBar?.setVisibility(View.INVISIBLE);
        }
    }


    public override fun onStart() {
        super.onStart()
        if (!checkPermissions()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions()
            }
        }
        else {
            getLastLocation()
        }
    }
    @SuppressLint("MissingPermission")
    private fun getLastLocation() {
        fusedLocationClient?.lastLocation!!.addOnCompleteListener(this) { task ->
            if (task.isSuccessful && task.result != null) {
                lastLocation = task.result
            }
            else {
                Log.w(TAG, "getLastLocation:exception", task.exception)
                showMessage("No location detected. Make sure location is enabled on the device.")
            }
        }
    }
    private fun showMessage(string: String) {
        val container = findViewById<View>(R.id.linearLayout)
        if (container != null) {
            Toast.makeText(this@Scanner, string, Toast.LENGTH_LONG).show()
        }
    }
    private fun showSnackbar(
        mainTextStringId: String, actionStringId: String,
        listener: View.OnClickListener
    ) {
        Toast.makeText(this@Scanner, mainTextStringId, Toast.LENGTH_LONG).show()
    }
    private fun checkPermissions(): Boolean {
        val permissionState = ActivityCompat.checkSelfPermission(
            this,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        return permissionState == PackageManager.PERMISSION_GRANTED
    }
    private fun startLocationPermissionRequest() {
        ActivityCompat.requestPermissions(
            this@Scanner,
            arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION),
            REQUEST_PERMISSIONS_REQUEST_CODE
        )
    }
    private fun requestPermissions() {
        val shouldProvideRationale = ActivityCompat.shouldShowRequestPermissionRationale(
            this,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (shouldProvideRationale) {
            Log.i(TAG, "Displaying permission rationale to provide additional context.")
            showSnackbar("Location permission is needed for core functionality", "Okay",
                View.OnClickListener {
                    startLocationPermissionRequest()
                })
        }
        else {
            Log.i(TAG, "Requesting permission")
            startLocationPermissionRequest()
        }
    }
    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        Log.i(TAG, "onRequestPermissionResult")
        if (requestCode == REQUEST_PERMISSIONS_REQUEST_CODE) {
            when {
                grantResults.isEmpty() -> {
                    // If user interaction was interrupted, the permission request is cancelled and you
                    // receive empty arrays.
                    Log.i(TAG, "User interaction was cancelled.")
                }
                grantResults[0] == PackageManager.PERMISSION_GRANTED -> {
                    // Permission granted.
                    getLastLocation()
                }
                else -> {
                    showSnackbar("Permission was denied", "Settings",
                        View.OnClickListener {
                            // Build intent that displays the App settings screen.
                            val intent = Intent()
                            intent.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
                            val uri = Uri.fromParts(
                                "package",
                                Build.DISPLAY, null
                            )
                            intent.data = uri
                            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                            startActivity(intent)
                        }
                    )
                }
            }
        }
    }
    companion object {
        private val TAG = "LocationProvider"
        private val REQUEST_PERMISSIONS_REQUEST_CODE = 34
    }

    override fun onSensorChanged(sensorEvent: SensorEvent?) {
        if (sensorEvent != null) {
            textTemperature?.text = "${sensorEvent?.values[0]} °C"
        }
    }


    override fun onAccuracyChanged(p0: Sensor?, p1: Int) {
    }

    override fun onPause() {
        super.onPause()
        sensorManager.unregisterListener(this)
    }

    override fun onResume() {
        super.onResume()
        if (isTempAvailable == true) {
            sensorManager.registerListener(this, tempSensor,SensorManager.SENSOR_DELAY_FASTEST)
        }
    }
}
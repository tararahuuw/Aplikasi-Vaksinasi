package com.example.perludilindungi

// import android.widget.Toast
// import com.google.android.material.snackbar.Snackbar
import BookmarkFragment
import android.content.Intent
import android.os.Bundle
import android.view.Window
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.example.perludilindungi.db.BookmarkDao
import com.example.perludilindungi.db.BookmarkDatabase
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import java.util.*


@Suppress("DEPRECATION")
class MainActivity : AppCompatActivity() {

    private lateinit var dao: BookmarkDao

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        setContentView(R.layout.activity_main)
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN)
        setContentView(R.layout.activity_main)
        supportActionBar?.hide()

        // Initialize the DAO..
        dao = BookmarkDatabase.getInstance(applicationContext).getBookmarkDao()

        val floating_button = findViewById<FloatingActionButton>(R.id.floatingButton)
        floating_button.setOnClickListener {
            // Toast.makeText(this, "Clicked", Toast.LENGTH_LONG).show()
            val intent = Intent (this, Scanner::class.java)
            startActivity(intent)

        }

        val fragment_news=NewsFragment()
        val fragment_location=LocationFragment()
        val fragment_bookmark=BookmarkFragment()

        if (savedInstanceState == null) {
            setCurrentFragment(fragment_news)
        }
        val bottom_navigation = findViewById<BottomNavigationView>(R.id.bottomNavigationView)
        bottom_navigation.setOnNavigationItemSelectedListener {
            when(it.itemId){
                R.id.news->setCurrentFragment(fragment_news)
                R.id.location->setCurrentFragment(fragment_location)
                R.id.bookmark->setCurrentFragment(fragment_bookmark)

            }
            true
        }
    }


    private fun setCurrentFragment(fragment:Fragment)=
        supportFragmentManager.beginTransaction().apply {
            replace(R.id.flFragment,fragment)
            commit()
        }

}
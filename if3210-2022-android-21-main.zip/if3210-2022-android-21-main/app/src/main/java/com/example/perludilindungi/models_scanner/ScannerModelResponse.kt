package com.example.perludilindungi.models_scanner

import com.google.gson.annotations.SerializedName

data class ScannerModelResponse (
//    val data : ModelData? = null
//        get() {
//            return field
//        }
    @field:SerializedName("data")
    val data: ModelData? = null
)
package com.example.perludilindungi.adapter

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.perludilindungi.CovidNewsFragment
import com.example.perludilindungi.R
import com.example.perludilindungi.models_news.NewsModel

class NewsAdapter(val results: NewsModel?) : RecyclerView.Adapter<NewsAdapter.ViewHolder>()  {

    class ViewHolder(ItemView: View) : RecyclerView.ViewHolder(ItemView) {
        val title_news: TextView = itemView.findViewById(R.id.title_news)
        val desc_news: TextView = itemView.findViewById(R.id.desc_news)
        val image_view: ImageView = itemView.findViewById(R.id.image_news)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NewsAdapter.ViewHolder {
        return ViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.card_news, parent, false))
    }

    override fun onBindViewHolder(holder: NewsAdapter.ViewHolder, @SuppressLint("RecyclerView") position: Int) {
        holder.title_news.text = results?.results?.get(position)?.title
        holder.desc_news.text = results?.results?.get(position)?.pubDate
        Glide.with(holder.image_view)
            .load(results?.results?.get(position)?.enclosure?._url)
            .into(holder.image_view)

        holder.itemView.setOnClickListener(object : View.OnClickListener{
            override fun onClick(p0: View?) {

                val bundle = Bundle()
                bundle.putString(
                    "urlNews",
                    results?.results?.get(position)?.link?.get(0).toString()
                )

                val frag2 = CovidNewsFragment()
                frag2.arguments = bundle
                val activity = p0!!.context as AppCompatActivity
                activity.supportFragmentManager.beginTransaction().replace(R.id.flFragment, frag2).addToBackStack(null).commit()
            }
        })
    }

    override fun getItemCount(): Int {
        return results?.count_total!!
    }
}
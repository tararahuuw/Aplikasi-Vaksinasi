package com.example.perludilindungi

import android.app.Application
import android.location.Location
import android.util.Log
import androidx.lifecycle.*
import com.example.perludilindungi.db.Bookmark
import com.example.perludilindungi.db.BookmarkDatabase
import com.example.perludilindungi.db.BookmarkRepository
import com.example.perludilindungi.model.faskes.FaskesModel
import com.example.perludilindungi.model.faskes.ResultFaskesModel
import com.example.perludilindungi.model.location.KotaModel
import com.example.perludilindungi.model.location.ProvinsiModel
import com.example.perludilindungi.retrofit.ApiServices
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class FaskesViewModel(application: Application): AndroidViewModel(application) {

    //Mutable Data: provinsi, kota, faskes
    private lateinit var province: MutableLiveData<List<String>>
    private lateinit var city: MutableLiveData<List<String>>
    private lateinit var faskes: MutableLiveData<List<ResultFaskesModel>>
    private lateinit var isBookmarkExist: MutableLiveData<Boolean>
    private val repository: BookmarkRepository


    //inisialisasi object mutable
    init {
        val bookmarkDao = BookmarkDatabase.getInstance(application).getBookmarkDao()
        province = MutableLiveData()
        city = MutableLiveData()
        faskes = MutableLiveData()
        isBookmarkExist = MutableLiveData()
        repository = BookmarkRepository(bookmarkDao)
    }

    // getter of mutable live data
    fun getMutableProv(): MutableLiveData<List<String>> { return province }
    fun getMutableCity(): MutableLiveData<List<String>> { return city }
    fun getMutableFaskes(): MutableLiveData<List<ResultFaskesModel>> { return faskes }
    fun getMutableisBookmarkExist(): MutableLiveData<Boolean> { return isBookmarkExist }
    fun getLiveFaskes() : LiveData<List<ResultFaskesModel>> = faskes

    // to inform the change of data
    // https://stackoverflow.com/questions/51299641/difference-of-setvalue-postvalue-in-mutablelivedata
    fun passProv(provinceList: List<String>){
        province.postValue(provinceList)
    }
    fun passCity(cityList: List<String>){
        city.postValue(cityList)
    }
    fun passFaskes(faskesList: List<ResultFaskesModel>?){
        faskes.postValue(faskesList!!)
    }

    fun passisBookmarkExist(exist: Boolean?){
        isBookmarkExist.postValue(exist!!)
    }

    fun callApiProvince(){
        ApiServices.endpoint.getProvince()
            .enqueue(object : Callback<ProvinsiModel> {
                override fun onResponse(call: Call<ProvinsiModel>, response: Response<ProvinsiModel>) {
                    //Toast.makeText(context, "Clicked", Toast.LENGTH_LONG).show()
                    Log.i("API", "ON Response Prov")
                    if (response.isSuccessful) {
                        println(response.body())
                        var provinceList: List<String> = emptyList()
                        provinceList = (response.body()?.results?.map {
                            it.value
                        } ?: println(provinceList)) as List<String>
                        passProv(provinceList)
                        Log.i("API PASS DATA", "SUCCESS Prov")
                    }
                }

                override fun onFailure(call: Call<ProvinsiModel>, t: Throwable) {
                    Log.i("API", "FAIL Prov")
                }
            })
    }

    fun callApiCity(province: String){
        ApiServices.endpoint.getCity(province)
            .enqueue(object : Callback<KotaModel> {
                override fun onResponse(call: Call<KotaModel>, response: Response<KotaModel>) {
                    Log.i("API", "ON Response City")
                    if (response.isSuccessful) {
                        println(response.body())
                        var cityList: List<String> = emptyList()
                        cityList = (response.body()?.results?.map {
                            it.value
                        } ?: println(cityList)) as List<String>
                        passCity(cityList)
                        Log.i("API PASS DATA", "SUCCESS City")

                    }
                }

                override fun onFailure(call: Call<KotaModel>, t: Throwable) {
                    Log.i("API", "FAIL City")
                }
            })
    }


    fun callApiFaskes(province: String, city: String, userLat: Double, userLong: Double) {
        ApiServices.endpoint.getFaskes(province, city)
            .enqueue(object : Callback<FaskesModel> {
                override fun onResponse(call: Call<FaskesModel>, response: Response<FaskesModel>) {
                    if (response.isSuccessful) {
                        val faskesList = response.body()
                        val faskesSorted = faskesList?.data?.let { sortFaskes(it, userLat, userLong) }
                        faskesList?.let{passFaskes(faskesSorted?.take(5))} }
                }
                override fun onFailure(call: Call<FaskesModel>, t: Throwable) {
                }
            })
    }

    fun sortFaskes(
        faskesList: List<ResultFaskesModel>,
        userLat: Double,
        userLong: Double
    ): List<ResultFaskesModel> {
        return faskesList.sortedBy {
            var i: Int = 0
            distanceInKm(
                faskesList.get(i).latitude.toDouble(),
                userLat,
                faskesList.get(i).longitude.toDouble(),
                userLong
            )
            i++
        }

    }

    fun distanceInKm(lat1: Double, lat2: Double, lon1: Double, lon2: Double): Double {
        val theta = lon1 - lon2
        var dist = Math.sin(deg2rad(lat1)) * Math.sin(deg2rad(lat2)) + Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * Math.cos(deg2rad(theta))
        dist = Math.acos(dist)
        dist = rad2deg(dist)
        dist = dist * 60 * 1.1515
        dist = dist * 1.609344
        return dist
    }

    private fun deg2rad(deg: Double): Double {
        return deg * Math.PI / 180.0
    }

    private fun rad2deg(rad: Double): Double {
        return rad * 180.0 / Math.PI
    }

    fun addBookmark(bookmark: Bookmark){
        viewModelScope.launch(Dispatchers.IO) {
            repository.addBookmark(bookmark)
            Log.i("TES123", repository.getBookmarkById(bookmark.id_api).toString())
        }
    }

    fun deleteBookmark(id_api: Int){
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteBookmarkById(id_api)
        }
    }

    fun getBookmark(id_api: Int){
        viewModelScope.launch(Dispatchers.IO) {
            passisBookmarkExist(repository.getBookmarkById(id_api))
        }
    }


}
package com.example.perludilindungi.models_news

class EnclosureModel {
    val _url : String = "null"
        get() {
            return field
        }
}
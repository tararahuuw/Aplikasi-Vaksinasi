package com.example.perludilindungi.model.faskes

class FaskesModel {
    val count_total : Int = 0
        get() {
            return field
        }

    val data : List<ResultFaskesModel>? = null
        get() {
            return field
        }
}
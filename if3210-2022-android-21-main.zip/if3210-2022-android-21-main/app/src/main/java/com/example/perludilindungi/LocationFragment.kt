package com.example.perludilindungi

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.databinding.DataBindingUtil
import androidx.databinding.DataBindingUtil.*
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.perludilindungi.adapter.LocationAdapter
import com.example.perludilindungi.adapter.NewsAdapter
import com.example.perludilindungi.databinding.FragmentLocationBinding
import kotlinx.android.synthetic.main.fragment_location.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProviders
import com.google.android.material.floatingactionbutton.FloatingActionButton
//import java.util.jar.Manifest
import com.example.perludilindungi.model.faskes.ResultFaskesModel as ResultFaskesModel
import com.vmadalin.easypermissions.EasyPermissions
import com.vmadalin.easypermissions.dialogs.SettingsDialog
import android.Manifest
import android.annotation.SuppressLint
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import kotlin.properties.Delegates

class LocationFragment : Fragment(), EasyPermissions.PermissionCallbacks {

    companion object {
        const val PERMISSION_LOCATION_REQUEST_CODE = 1
    }
    private lateinit var _binding: FragmentLocationBinding
    private val binding get() = _binding
    private lateinit var sharedViewModel: FaskesViewModel
    private lateinit var fusedLocationProviderClient: FusedLocationProviderClient
    private var userLatitude : Double = 0.0
    private var userLongitude : Double = 0.0

//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//    }


    @SuppressLint("MissingPermission")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        _binding = FragmentLocationBinding.inflate(inflater, container, false)
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(requireContext())

        if(hasLocationPermission()){
            fusedLocationProviderClient.lastLocation.addOnSuccessListener {
                if (userLatitude != null && userLongitude != null){
                    userLatitude = it.latitude
                    userLongitude = it.longitude
                } else {
                    userLatitude = 0.0
                    userLongitude = 0.0
                }
            }
        } else {
            requestLocationPermission()
        }
        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        sharedViewModel = ViewModelProviders.of(requireActivity()).get(FaskesViewModel::class.java)
        val progressBar1 = binding.progressBarLocation

        binding.ProvinceDropdown?.setOnDismissListener {
            progressBar1?.setVisibility(View.VISIBLE);
            getDataCity(binding.ProvinceDropdown!!.text.toString())
        }

        binding.CityDropdown?.setOnDismissListener {
            val provinsi = binding.ProvinceDropdown?.text.toString()
            val kota = binding.CityDropdown?.text.toString()
            binding.SearchFaskes?.setOnClickListener{
                progressBar1?.setVisibility(View.VISIBLE);
                getDataFaskes(provinsi,kota)}

        }
        getDataProvince()

    }
    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        sharedViewModel = ViewModelProvider(requireActivity())[FaskesViewModel::class.java]
        Log.d("ACTIVITY","activity created")
    }

    override fun onViewStateRestored(savedInstanceState: Bundle?) {
        super.onViewStateRestored(savedInstanceState)
        sharedViewModel = ViewModelProviders.of(requireActivity()).get(FaskesViewModel::class.java)
        getLiveDataFaskes()
    }

    fun getDataProvince(){
        val progressBar1 = binding.progressBarLocation
        sharedViewModel.getMutableProv().observe(viewLifecycleOwner, Observer<List<String>>{
            if (it != null) {
                Log.i("mutable","SUCCESS Prov")
                progressBar1?.setVisibility(View.GONE);
                val arrayAdapter =
                    activity?.let { it1 -> ArrayAdapter(it1, R.layout.dropdown_location, it) }
                binding.ProvinceDropdown?.setAdapter(arrayAdapter)
            } else {
                Toast.makeText(context, "Error", Toast.LENGTH_LONG).show()
            }
        })
        sharedViewModel.callApiProvince()
    }


    fun getDataCity(provinsi: String){
        val progressBar1 = binding.progressBarLocation
        sharedViewModel.getMutableCity().observe(viewLifecycleOwner, Observer<List<String>>{
            if (it != null) {
                Log.i("mutable","SUCCESS City")
                progressBar1?.setVisibility(View.GONE);
                val arrayAdapter =
                    activity?.let { it1 -> ArrayAdapter(it1, R.layout.dropdown_location, it) }
                binding.CityDropdown?.setAdapter(arrayAdapter)
            } else {
                Toast.makeText(context, "Error", Toast.LENGTH_LONG).show()
            }
        })
        sharedViewModel.callApiCity(provinsi)
    }

    fun getDataFaskes(provinsi: String, kota: String) {
        val progressBar1 = binding.progressBarLocation
        sharedViewModel = ViewModelProviders.of(requireActivity()).get(FaskesViewModel::class.java)
        sharedViewModel.getMutableFaskes().observe(viewLifecycleOwner, Observer<List<ResultFaskesModel>>{
            progressBar1?.setVisibility(View.GONE);
            if (it != null) {
                recyclerViewFaskes.layoutManager = LinearLayoutManager(activity)
                var faskesAdapter = LocationAdapter(it)
                recyclerViewFaskes.adapter = faskesAdapter

            } else {
                Toast.makeText(this.context, "Error", Toast.LENGTH_LONG).show()
            }

        })
        sharedViewModel.callApiFaskes(provinsi, kota, userLatitude, userLongitude)
    }
    fun getLiveDataFaskes(){
        val progressBar1 = binding.progressBarLocation
        sharedViewModel.getLiveFaskes().observe(viewLifecycleOwner, Observer<List<ResultFaskesModel>>{
            progressBar1?.setVisibility(View.GONE);
            if (it != null){
                recyclerViewFaskes.layoutManager = LinearLayoutManager(activity)
                recyclerViewFaskes.adapter = LocationAdapter(it)
            } else {
                Log.i("Live Data","ERROR")
                Toast.makeText(this.context, "Live Data Error", Toast.LENGTH_LONG).show()
            }

        })
    }
    private fun hasLocationPermission() =
        EasyPermissions.hasPermissions(
            requireContext(),
            Manifest.permission.ACCESS_FINE_LOCATION
        )

    private fun requestLocationPermission() {
        EasyPermissions.requestPermissions(
            this,
            "This application cannot work without Location Permission.",
            PERMISSION_LOCATION_REQUEST_CODE,
            Manifest.permission.ACCESS_FINE_LOCATION
        )
    }
    override fun onPermissionsDenied(requestCode: Int, perms: List<String>) {
        if (EasyPermissions.somePermissionPermanentlyDenied(this, perms)) {
            SettingsDialog.Builder(requireActivity()).build().show()
        } else {
            requestLocationPermission()
        }
    }

    override fun onPermissionsGranted(requestCode: Int, perms: List<String>) {
        Toast.makeText(
            requireContext(),
            "Permission Granted!",
            Toast.LENGTH_SHORT
        ).show()
        setViewVisibility()
    }

    private fun setViewVisibility() {
        if (hasLocationPermission()) {
            binding.recyclerViewFaskes.visibility = View.VISIBLE
        } else {
            binding.recyclerViewFaskes.visibility = View.GONE
        }
    }


}


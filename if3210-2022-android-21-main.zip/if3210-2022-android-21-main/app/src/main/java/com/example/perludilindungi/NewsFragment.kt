package com.example.perludilindungi

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.perludilindungi.adapter.NewsAdapter
import com.example.perludilindungi.models_news.NewsModel
import com.example.perludilindungi.retrofit.ApiServices
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class NewsFragment : Fragment() {

    private var layoutManager: RecyclerView.LayoutManager? = null
    private var adapter: RecyclerView.Adapter<NewsAdapter.ViewHolder>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_news, container, false)

    }

    override fun onViewCreated(itemView: View, savedInstanceState: Bundle?) {
        super.onViewCreated(itemView, savedInstanceState)

        val progressBar : ProgressBar = itemView.findViewById(R.id.progressBar)
        progressBar.setVisibility(View.VISIBLE);
        ApiServices.endpoint.getNews()
            .enqueue(object : Callback<NewsModel> {
                override fun onResponse(call: Call<NewsModel>, response: Response<NewsModel>) {
                    progressBar.setVisibility(View.GONE);
                    if (response.isSuccessful) {
                        var recycler_view: RecyclerView = itemView.findViewById(R.id.recyclerView)
                        recycler_view.apply {
                            // set a LinearLayoutManager to handle Android
                            // RecyclerView behavior
                            layoutManager = LinearLayoutManager(activity)
                            // set the custom adapter to the RecyclerView
                            adapter = NewsAdapter(response.body())
                        }
                    }
                }

                override fun onFailure(call: Call<NewsModel>, t: Throwable) {
                    progressBar.setVisibility(View.GONE);
                    Log.i("get", "gagal")
                }

            })
    }
}
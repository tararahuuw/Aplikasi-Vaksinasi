package com.example.perludilindungi.models_scanner

class ModelData {
    val userStatus : String? = null
        get() {
            return field
        }

    val reason : String? = null
        get() {
            return field
        }

}
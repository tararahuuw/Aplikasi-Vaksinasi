package com.example.perludilindungi.adapter

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.ui.graphics.Color
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.RecyclerView
import com.example.perludilindungi.CovidNewsFragment
import com.example.perludilindungi.FaskesLocationFragment
import com.example.perludilindungi.R
import com.example.perludilindungi.model.faskes.FaskesModel
import com.example.perludilindungi.model.faskes.ResultFaskesModel
import com.google.android.material.bottomnavigation.BottomNavigationView

class LocationAdapter(private val results: List<ResultFaskesModel>) : RecyclerView.Adapter<LocationAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemView =
            LayoutInflater.from(parent.context).inflate(R.layout.card_faskes, parent, false)
        return ViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: ViewHolder, @SuppressLint("RecyclerView") position: Int) {
        holder.nama.text = results?.get(position)?.nama
        holder.kode.text = "KODE : "+results?.get(position)?.kode
        holder.alamat.text = results?.get(position)?.alamat
        holder.telepon.text = results?.get(position)?.telp
        holder.jenis.text = results?.get(position)?.jenis_faskes

        if (holder.jenis.text.toString().lowercase()=="puskesmas") {
            holder.jenis.setBackgroundColor(Color.Magenta.hashCode())
        }
        else if (holder.jenis.text.toString().lowercase()=="rumah sakit") {
            holder.jenis.setBackgroundColor(Color.Blue.hashCode())
        }
        else if (holder.jenis.text.toString().lowercase()=="klinik") {
            holder.jenis.setBackgroundColor(R.color.purple_200)
        }
        else {
            holder.jenis.setBackgroundColor(Color.Red.hashCode())
        }

        holder.itemView.setOnClickListener(object : View.OnClickListener {
            override fun onClick(p0: View?) {

                val bundle = Bundle()
                bundle.putInt("id", results.get(position).id)
                bundle.putString("kode", results.get(position).kode)
                bundle.putString("nama", results.get(position).nama)
                bundle.putString("alamat", results.get(position).alamat)
                bundle.putString("telp", results.get(position).telp)
                bundle.putString("jenis_faskes", results.get(position).jenis_faskes)
                bundle.putString("status", results.get(position).status)
                bundle.putDouble("latitude", results.get(position).latitude.toDouble())
                bundle.putDouble("longitude", results.get(position).longitude.toDouble())

                val frag2 = FaskesLocationFragment()
                frag2.arguments = bundle
                val activity = p0!!.context as AppCompatActivity
                activity.supportFragmentManager.beginTransaction()
                    .replace(R.id.flFragment, frag2).addToBackStack(null).commit()
            }
        })

    }

    override fun getItemCount(): Int {
        return 5
    }

    class ViewHolder(ItemView: View) : RecyclerView.ViewHolder(ItemView) {
        val nama: TextView = itemView.findViewById(R.id.nama)
        val kode: TextView = itemView.findViewById(R.id.kode)
        val alamat: TextView = itemView.findViewById(R.id.alamat)
        val telepon: TextView = itemView.findViewById(R.id.telp)
        val jenis: TextView = itemView.findViewById(R.id.jenis_faskes)
    }
}
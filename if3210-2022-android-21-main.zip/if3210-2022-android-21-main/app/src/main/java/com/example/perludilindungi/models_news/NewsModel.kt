package com.example.perludilindungi.models_news

class NewsModel {
    val count_total : Int = 0
        get() {
            return field
        }

    val results : Array<ResultNewsModel>? = null
        get() {
            return field
        }
}
package com.example.perludilindungi

import android.content.Intent
import android.graphics.Color.red
import android.net.Uri
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.perludilindungi.adapter.LocationAdapter
import com.example.perludilindungi.databinding.FragmentFaskesLocationBinding
import com.example.perludilindungi.databinding.FragmentLocationBinding
import com.example.perludilindungi.db.Bookmark
import com.example.perludilindungi.db.BookmarkViewModel
import com.example.perludilindungi.model.faskes.ResultFaskesModel
import kotlinx.android.synthetic.main.fragment_location.*
import kotlin.properties.Delegates

class FaskesLocationFragment : Fragment() {

    private lateinit var _binding: FragmentFaskesLocationBinding
    private lateinit var sharedViewModel: FaskesViewModel
    private val binding get() = _binding
    private var lat : Double = 0.0
    private var long : Double = 0.0

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentFaskesLocationBinding.inflate(inflater, container, false)

        //get data faskes
        val bundle:Bundle? = arguments
        val id_api: Int? = bundle?.getInt("id")
        val kode: String? = bundle?.getString("kode")
        val nama: String? = bundle?.getString("nama")
        val alamat: String? = bundle?.getString("alamat")
        val telp: String? = bundle?.getString("telp")
        val jenis_faskes: String? = bundle?.getString("jenis_faskes")
        val status: String? = bundle?.getString("status")
        val latitude: Double? = bundle?.getDouble("latitude")
        val longitude: Double? = bundle?.getDouble("longitude")
        if (latitude != null && longitude != null) {
            this.lat = latitude
            this.long = longitude
        }

        //put data faskes in layout
        val namaDF = binding.namaDetailFaskes
        namaDF.setText(nama)
        val kodeDF = binding.kodeDetailFaskes
        kodeDF.setText(kode)
        val jenisDF = binding.jenisDetailFaskes
        jenisDF.setText(jenis_faskes)
        val alamatDF = binding.alamatDetailFaskes
        alamatDF.setText(alamat)
        val telpDF = binding.telpDetailFaskes
        telpDF.setText(telp)
        val statusDF = binding.statusDetailFaskes
        if (status?.lowercase()=="siap vaksinasi"){
            statusDF.setImageResource(R.drawable.vaksin_siap)
        } else { statusDF.setImageResource(R.drawable.vaksin_tidaksiap)}

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val progressBar : ProgressBar = view.findViewById(R.id.progressBar)
        progressBar.setVisibility(View.VISIBLE)

        //get data faskes
        val bundle:Bundle? = arguments

        val id_api: Int = bundle!!.getInt("id")
        val kode: String? = bundle?.getString("kode")
        val nama: String? = bundle?.getString("nama")
        val alamat: String? = bundle?.getString("alamat")
        val telp: String? = bundle?.getString("telp")
        val jenis_faskes: String? = bundle?.getString("jenis_faskes")
        val status: String? = bundle?.getString("status")
        val longitude: Double? = bundle?.getDouble("longitude")
        val latitude: Double? = bundle?.getDouble("latitude")

        sharedViewModel = ViewModelProviders.of(this)[FaskesViewModel::class.java]
        sharedViewModel.getBookmark(id_api)

        sharedViewModel.getMutableisBookmarkExist().observe(viewLifecycleOwner, Observer<Boolean>{

            if (it) {
                binding.bookmarkButton.text = "Unbookmark"
                binding.bookmarkButton.setBackgroundColor(Color.Magenta.hashCode())
            }
            else {
                binding.bookmarkButton.text = "Bookmark"
                binding.bookmarkButton.setBackgroundColor(Color.Blue.hashCode())
            }

            val value = it

            binding.bookmarkButton?.setOnClickListener {
                Log.i("Bookmark", "Clicked")
                if (value) {
                    deleteDataFromDatabase(id_api)
                }
                else {
                    insertDataToDatabase(Bookmark(
                        id_api,
                        kode.toString(),
                        nama.toString(),
                        alamat.toString(),
                        telp.toString(),
                        jenis_faskes.toString(),
                        status.toString(),
                        longitude?: 0.0,
                        latitude?: 0.0
                    ))
                }
            }
            sharedViewModel.getBookmark(id_api)
        })

        progressBar.setVisibility(View.GONE)
        binding.gMapsButton?.setOnClickListener {
            Log.i("MAPS", "Clicked")
            toGMaps(lat,long)
            Log.i("MAPS", "Load")
        }
    }

    fun toGMaps(lat: Double, long: Double){
        val gmmIntentUri = Uri.parse("geo:${lat},${long}")
        println(gmmIntentUri)
        val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri)
        mapIntent.setPackage("com.google.android.apps.maps")
        startActivity(mapIntent)
    }

    private fun insertDataToDatabase(bookmark: Bookmark) {
        Log.i("BOOKMARK", bookmark.toString())
        sharedViewModel.addBookmark(bookmark)
        sharedViewModel.getBookmark(bookmark.id_api)

        Toast.makeText(requireContext(), "Successfully added!", Toast.LENGTH_LONG).show()
    }

    private fun deleteDataFromDatabase(id_api: Int) {
        Log.i("BOOKMARK", id_api.toString())
        sharedViewModel.deleteBookmark(id_api)
        sharedViewModel.getBookmark(id_api)

        Toast.makeText(requireContext(), "Successfully deleted!", Toast.LENGTH_LONG).show()
    }

}

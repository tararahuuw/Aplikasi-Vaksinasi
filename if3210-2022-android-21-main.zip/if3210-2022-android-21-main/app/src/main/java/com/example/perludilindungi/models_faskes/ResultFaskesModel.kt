package com.example.perludilindungi.model.faskes

class ResultFaskesModel {
    val id : Int = 0
        get() { return field }
    val kode : String = "null"
        get() { return field }
    val nama : String = "null"
        get() { return field }
    val kota : String = "null"
        get() { return field }
    val provinsi : String = "null"
        get() { return field }
    val alamat : String = "null"
        get() { return field }
    val latitude : String = "null"
        get() { return field }
    val longitude : String = "null"
        get() { return field }
    val telp : String = "null"
        get() { return field }
    val jenis_faskes : String = "null"
        get() { return field }
    val status : String = "null"
        get() { return field }
}

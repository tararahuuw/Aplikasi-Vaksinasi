# IF3210-2022-Android-21

## Aplikasi Perlu Dilindungi

### Deskripsi Aplikasi

Dalam tugas besar kali ini, peserta diminta untuk membangun sebuah aplikasi pada platform Android bernama **Aplikasi Perlu Dilindungi**.
Berikut adalah spesifikasi yang harus dipenuhi oleh Aplikasi Perlu Dilindungi:

1. **Menampilkan Berita COVID-19**
Pengguna dapat melihat berita COVID-19 melalui API Perlu Dilindungi. Terdapat halaman untuk menampilkan list berita dan setiap item dapat dibuka untuk menampilkan WebView dengan konten sesuai URL berita.

2. **Menampilkan Daftar Faskes untuk Vaksinasi**
Pengguna dapat mencari tempat vaksinasi terdekat menggunakan API Perlu Dilindungi.
Pengguna perlu memilih provinsi dan kota lokasi faskes yang ingin dicari terlebih dahulu. Setelah itu, pengguna dapat menekan tombol search yang akan menampilkan maksimal lima faskes terdekat ke tempat pengguna.

3. **Menampilkan Detail Informasi Faskes**
Untuk setiap tempat yang didapat dari hasil penampilan daftar faskes, dapat dibuka halaman baru yang berisi detail informasi. Pada halaman detail juga terdapat tombol Google Maps (mengarahkan pengguna pada peta lokasi) dan tombol Bookmark (menyimpan faskes pada bookmark).

4. **Menampilkan Daftar Bookmark Faskes**
Pengguna dapat menampilkan daftar bookmark faskes dalam bentuk list. Faskes yang di bookmark dapat ditekan yang kemudian akan membuka halaman detail dari faskes tersebut.

5. **Melakukan "Check-In"**
Pengguna dapat menggunakan halaman QR Code Scanner bawaan aplikasi untuk melakukan check in. String yang diperoleh dari QR Code beserta dengan informasi latitude dan longitude pengguna akan dikirimkan ke server Perlu Dilindungi yang dapat diakses di API Perlu Dilindungi.


### Cara Kerja
<details>
  <summary>1. Menampilkan Berita COVID-19</summary>

A. Splash Screen
- Author : Fariz Aziz
- Pendekatan :
  - Membuat Activity Baru

B. Bottom Navigation
- Author : Muhammad Fahmi Alamsyah, Faris Aziz
- Pendekatan : 
  - Membuat Component Bottom Navigation pada activity_main.xml
  - Membuat XML Menu pada bottom_nav_menu.xml
  - Membuat logika berdasarkan id fragment yang terpilih pada file Kotlin MainActivity.kt
  
C. Menampilkan Recyclerview Berita
- Author : Muhammad Fahmi Alamsyah
- Pendekatan :
  - Membuat komponen recycleview pada framelayout
  - Membuat class model
  - Membuat membuat layout card
  - Membuat adapter
  
D. Get Data News
- Author : Muhammad Fahmi Alamsyah
- Pendekatan :
  - Membuat Api Endpoint
  - Membuat Api Service
  
E. Menampilkan berita dengan webview
- Author : Muhammad Fahmi Alamsyah
- Pendekatan :
  - Mengirim url data bundle dari onClick Adapter
  - Menangkap url data dari bundle
  - Membuat komponen Webview
  - Membuat logika dan load web dari hasil url data
</details>
<details>
  <summary>2. Menampilkan Daftar Faskes untuk Vaksinasi</summary>
  
A. Fetching Data Provinsi dan Kota
- Author : Aulia Adila
- Pendekatan :
    - Membuat Api Get
    - Memanggil api pada saat komponen di create
    - Menggunakan shared view model, mutable live data, data binding
 
B. Membuat Dropdown
- Author : Aulia Adila
- Pendekatan :
    - Membuat komponen dropdown
    - Memasukkan data hasil fetching data

C. Akses Location
- Author : Aulia Adila
- Pendekatan :
  - Setting location Permission
  - Mendapatkan latitude dan longitude

D. Menampilkan RecycleView
- Author : Aulia Adila
- Pendekatan :
  - Mengurutkan 5 lokasi terdekat
  - Membuat komponen recycleview pada framelayout
  - Membuat class model
  - Membuat membuat layout card
  - Membuat adapter
  
E. Responsive layout
- Author : Aulia Adila, Muhammad Fahmi Alamsyah
- Pendekatan :
  - Membuat shared view model dan live data
  - Membuat xml landscape
  
</details>

<details>
  <summary>3. Menampilkan Detail Informasi Faskes</summary>
  
A. Membuat Layout Detail
- Author : Aulia Adila, Muhammad Fahmi Alamsyah
- Pendekatan :
    - Membuat XML Layout

B. Fetching Data
- Author : Aulia Adila
- Pendekatan :
    - Mempassing data dari recycleview dengan bundle
  
C. Google MAPS
- Author : Aulia Adila
- Pendekatan :
  - Setting location Permission
  - Intent Google Maps dengan data lokasi
  
</details>
<details>
<summary>4. Menampilkan Daftar Bookmark Faskes</summary>

A. Setup Sqlite
- Author : Fariz Aziz
- Pendekatan :
  - Setup Sqlite
  - Membuat Data Class Bookmark
  - Membuat Database Bookmark
  - Membuat Database Repository
  
B. Menampilkan Recyleview dari list bookmark
- Author : Faris Aziz
- Pendekatan :
  - Membuat komponen recycleview pada framelayout
  - Membuat class model
  - Membuat membuat layout card
  - Membuat adapter
  
C. Menambahkan bookmark
- Author : Faris Aziz
- Pendekatan :
  - Membuat onClicklistener pada button bookmark
  - Memasukkan ke dalam recycler view

D. Menghapus bookmark
- Author : Faris Aziz
- Pendekatan :
  - Membuat onClicklistener pada button bookmark
  - Membuat variabel MutableLiveData pada View Model  
</details>
<details>
<summary>5. Melakukan "Check-In"</summary>

A. Floating Button
- Author : Aulia Adila
- Pendekatan :
 - Membuat Component Floating Button pada activity_main.xml
 - Membuat logika berdasarkan id fragment yang terpilih pada file Kotlin MainActivity.kt, serta memanfaatkan intent 

B. Camera Scanner **(Harus Pada Device Asli Karena Terkadang AVD Tidak Support Camera Live)**
- Author : Muhammad Fahmi Alamsyah
- Pendekatan :
  - Setting Camera Permission
  - Camera access sesuai dokumentasi android
  
C. Location
- Author : Muhammad Fahmi Alamsyah
- Pendekatan :
  - Setting location Permission
  - Mendapatkan latitude dan longitude
  
D. Post API
- Author : Muhammad Fahmi Alamsyah
- Pendekatan :
  - Membuat post api
  - Memasukkan parameter qrCode, latitude, dan longitude
  
E. Temperature **(Harus Pada Emulator Karena Terkadang HP Tidak Support Sensor Suhu)**
- Author : Muhammad Fahmi Alamsyah
- Pendekatan :
  - Setting ambient temperature sensor
  - Access temperature sensor sesuai dokumentasi android
</details>

### Library
1. Retrofit : Mempermudah Proses Fetching
2. Material Design : Membuat komponen yang mudah dan indah
3. GSON : Untuk memproses data hasil fetching retrofit
4. C0oroutine : Untuk mengatur thread pada bagian sqlite
5. Okhttp : Untuk mempermudah mengetahui message dari fetching data
6. Glide : Menampilkan gambar dari url
7. Room : Untuk mengaur database sqlite room
8. ViewModel : Untuk membuat komponen view-model
9. LiveData : Data holder class yang aware dengan lifecycle komponen lain
10. EasyPermission : Untuk memudahkan dalam akses permission
11. Play Service Location : Untuk mendapatkan latitude longitude

### Screenshot
<details>
  <summary>1. Menampilkan Berita COVID-19</summary>

A. Splash Screen

![](image/PBD1.jpg)
  
B. Menampilkan Recyclerview berita & Bottom Navigation

![](image/PBD2.jpg)
  
C. Menampilkan berita dengan Webview

![](image/PBD3.jpg)
</details>
<details>
  <summary>2. Menampilkan Daftar Faskes untuk Vaksinasi (Harus Menggunakan HP Karena Terkadang AVD Tidak Support Location Sehingga Bisa Terjadi ForceClose)</summary>

A. Memilih Faskes

![](image/PBD4.jpg)
  
B. Menampilkan Recyclerview Faskes 5 Terdekat

![](image/PBD5.jpg)
  
C. Responsive Design Faskes

![](image/PBD6.jpg)
</details>

<details>
  <summary>3. Menampilkan Detail Informasi Faskes</summary>

A. Menampilkan Detail Faskes

![](image/PBD7.jpg)
  
B. Bookmark Faskes

![](image/PBD8.jpg)
  
C. Unbookmark Faskes

![](image/PBD7.jpg)

D. Membuka Google Maps

![](image/PBD14.jpg)
</details>

<details>
  <summary>4. Menampilkan Daftar Bookmark Faskes</summary>

A. Menampilkan Daftar Bookmark

![](image/PBD9.jpg)
  
B. Membuka Detail Faskes Dari Bookmark

![](image/PBD8.jpg)
</details>

<details>
  <summary>5. Melakukan "Check-In"</summary>

A. Menampilkan Hasil Scanner (Harus pada HP karena terkadang AVD tidak support camera live)

![](image/PBD10.jpg)

![](image/PBD11.jpg)

![](image/PBD12.jpg)

![](image/PBD13.jpg)
  
B. Menampilkan Temperature (Harus pada AVD karena terkadang HP tidak support sensor suhu)

![](image/PBD15.jpg)
</details>

### Pembagian Kerja
1. Splash Screen : Faris Aziz (13519065)
2. Bottom Navigation : Muhammad Fahmi Alamsyah (13519077), Faris Aziz (13519065)
3. Floating Button : Aulia Adila (13519100)
4. Menampilkan list news : Muhammad Fahmi Alamsyah (13519077)
5. Menampilkan web news : Muhammad Fahmi Alamsyah (13519077)
6. Fetching API : Muhammad Fahmi Alamsyah (13519077), Aulia Adila (13519100)
7. Menampilkan daftar faskes vaksinasi : Aulia Adila (13519100), Muhammad Fahmi Alamsyah (13519077)
8. Menampilkan informasi faskes : Aulia Adila (13519100), Muhammad Fahmi Alamsyah (13519077)
9. Menampilkan Gmaps : Aulia Adila (13519100)
10. Setup Sqlite : Faris Aziz (13519065)
11. Menampilkan list bookmark : Faris Aziz (13519065)
12. Menambahkan bookmark : Faris Aziz (13519065)
13. Menghapus bookmark : Faris Aziz (13519065)
14. Scan Barcode : Muhammad Fahmi Alamsyah (13519077)
15. Fetching location : Muhammad Fahmi Alamsyah (13519077), Aulia Adila (13519100)
16. Temperature : Muhammad Fahmi Alamsyah (13519077)
17. Responsive : Muhammad Fahmi Alamsyah (13519077), Aulia Adila (13519100)
